//Examen
public class main {

    public static void main(String[] args) throws InterruptedException {
        // TODO code application logic here
        Tread a = new Tread();
        a.Maximo();
    }
    
}
